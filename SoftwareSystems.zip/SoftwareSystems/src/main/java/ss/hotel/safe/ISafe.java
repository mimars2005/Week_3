package ss.hotel.safe;

public interface ISafe {

}
